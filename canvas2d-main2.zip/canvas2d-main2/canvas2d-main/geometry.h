#ifndef GEOMETRY_H
#define GEOMETRY_H

// 纯几何算法模块（实验二裁剪），不依赖 Qt/RenderTarget，保持低耦合
#include <algorithm>
#include <cmath>
#include <optional>
#include <utility>
#include <vector>

#include "point.h"

namespace Geometry {

// 叉积 (b-a) × (c-a)
inline double cross(Point a, Point b, Point c)
{
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

// 有符号面积的两倍；y 向下坐标系中 <0 对应屏幕逆时针绕序
inline double signedArea2(const std::vector<Point> &p)
{
    double s = 0;
    for (std::size_t i = 0; i < p.size(); ++i) {
        const Point &a = p[i];
        const Point &b = p[(i + 1) % p.size()];
        s += a.x * b.y - b.x * a.y;
    }
    return s;
}

inline Point centroid(const std::vector<Point> &p)
{
    Point s{0, 0};
    for (const auto &q : p) {
        s = s + q;
    }
    return p.empty() ? s : s / static_cast<double>(p.size());
}

// 凸多边形窗口增量构造（实验二-4 窗口确定）：
// pts 为固定绕序（signedArea2 <= 0，屏幕逆时针）的凸 n 边形环序顶点，
// 判定新点 p 是否“有且仅有对一条边与重心异侧”。
// 合法时返回该边的起点下标 i（新点应插入 pts[i] 与 pts[(i+1)%n] 之间），
// 否则返回 -1（点在内部/边界上，或对多条边异侧）。
inline int convexInsertEdge(const std::vector<Point> &pts, Point p)
{
    const std::size_t n = pts.size();
    if (n < 3) {
        return -1;
    }
    const Point c = centroid(pts);
    int outside = -1;
    for (std::size_t i = 0; i < n; ++i) {
        const Point &a = pts[i];
        const Point &b = pts[(i + 1) % n];
        const double sc = cross(a, b, c);
        const double sp = cross(a, b, p);
        if (sc * sp < 0) { // 严格异侧
            if (outside != -1) {
                return -1; // 多于一条边异侧：不合法
            }
            outside = static_cast<int>(i);
        }
    }
    return outside; // -1 表示点在内部/边上，同样不合法
}

// 由两个已确认点 + 新点生成固定绕序的三角形；共线返回 false
inline bool makeTriangle(Point a, Point b, Point p, std::vector<Point> &out)
{
    if (std::abs(cross(a, b, p)) < 1e-9) {
        return false;
    }
    out = {a, b, p};
    if (signedArea2(out) > 0) {
        std::swap(out[1], out[2]); // 统一为屏幕逆时针绕序
    }
    return true;
}

// 线段 S->E 与直线 A->B 的交点参数 t（P = S + t·(E-S)）
inline double edgeIntersectParam(Point s, Point e, Point a, Point b)
{
    const double ux = e.x - s.x;
    const double uy = e.y - s.y;
    const double vx = b.x - a.x;
    const double vy = b.y - a.y;
    const double denom = ux * vy - uy * vx;
    return ((a.x - s.x) * vy - (a.y - s.y) * vx) / denom;
}

// Sutherland-Hodgman：用凸裁剪窗口（屏幕逆时针绕序）裁剪多边形 subject
inline std::vector<Point> clipPolygon(const std::vector<Point> &subject,
                                      const std::vector<Point> &clip)
{
    std::vector<Point> out = subject;
    const std::size_t m = clip.size();
    for (std::size_t i = 0; i < m && !out.empty(); ++i) {
        const Point a = clip[i];
        const Point b = clip[(i + 1) % m];
        std::vector<Point> in = std::move(out);
        out.clear();
        // 屏幕逆时针绕序：内部满足 cross(a,b,p) <= 0
        auto inside = [&](Point p) { return cross(a, b, p) <= 1e-9; };
        Point s = in.back();
        bool sin = inside(s);
        for (const Point &e : in) {
            const bool ein = inside(e);
            if (sin) {
                if (ein) {
                    out.push_back(e); // 内->内
                } else {
                    const double t = edgeIntersectParam(s, e, a, b);
                    out.push_back(
                        Point{s.x + t * (e.x - s.x), s.y + t * (e.y - s.y)});
                }
            } else if (ein) {
                const double t = edgeIntersectParam(s, e, a, b);
                out.push_back(
                    Point{s.x + t * (e.x - s.x), s.y + t * (e.y - s.y)});
                out.push_back(e); // 外->内
            }
            s = e;
            sin = ein;
        }
    }
    return out;
}

// 整圆按 seg 段采样为多边形（裁剪时圆不再是圆，结果用多边形表示）
inline std::vector<Point> circleToPolygon(Point center, double radius,
                                          int seg = 64)
{
    std::vector<Point> pts;
    pts.reserve(seg);
    for (int i = 0; i < seg; ++i) {
        const double t = 2.0 * M_PI * i / seg;
        pts.push_back(
            Point{center.x + radius * std::cos(t), center.y + radius * std::sin(t)});
    }
    return pts;
}

// 直线段对凸多边形窗口的裁剪（Liang-Barsky 凸多边形版）
// 窗口 clip 必须为屏幕逆时针绕序的凸多边形（内部满足 cross(a,b,p) <= 0）。
// 返回裁剪后的 (起,止)；整段在窗外时返回 std::nullopt。
inline std::optional<std::pair<Point, Point>>
clipLineSegment(Point s, Point e, const std::vector<Point> &clip)
{
    double t0 = 0.0;
    double t1 = 1.0;
    const Point d = e - s;
    for (std::size_t i = 0; i < clip.size(); ++i) {
        const Point a = clip[i];
        const Point b = clip[(i + 1) % clip.size()];
        // cross(a,b,P(t)) = (b-a)×(P(t)-a) = C0 + t*C1
        const double C0 = cross(a, b, s);
        const double C1 = (b.x - a.x) * d.y - (b.y - a.y) * d.x;
        // 内部条件 C0 + t*C1 <= 0
        if (std::abs(C1) < 1e-12) {
            if (C0 > 1e-9) {
                return std::nullopt; // 平行且在外侧
            }
        } else if (C1 > 0.0) {
            t1 = std::min(t1, -C0 / C1); // 出边
        } else {
            t0 = std::max(t0, -C0 / C1); // 入边
        }
    }
    if (t0 > t1 + 1e-9) {
        return std::nullopt;
    }
    t0 = std::max(t0, 0.0);
    t1 = std::min(t1, 1.0);
    if (t1 - t0 < 1e-9) {
        return std::nullopt;
    }
    return std::make_pair(Point{s.x + t0 * d.x, s.y + t0 * d.y},
                          Point{s.x + t1 * d.x, s.y + t1 * d.y});
}

// 圆弧对凸多边形窗口的裁剪
// 弧由 center/radius + 端点 ep1/ep2 + side 定义（与 Circle::ArcData 同语义：
// cross(ep2-ep1, p-ep1)*side > 0 的弧段被保留）。
// 返回裁剪后保留的若干段弧 (a,b)，方向与原弧一致（side 沿用原值）；
// 弧整段在窗外时返回空 vector。
struct ArcSeg {
    Point a;
    Point b;
    int side; // 与 Circle::ArcData::side 同语义：保留 cross(b-a, p-a)*side > 0 的一侧
};

// 直线 a→b 与圆的交点相对圆心的极角（弧度），最多两个
inline std::vector<double> circleEdgeAngles(Point center, double radius,
                                           Point a, Point b)
{
    std::vector<double> out;
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double fx = a.x - center.x;
    const double fy = a.y - center.y;
    const double A = dx * dx + dy * dy;
    if (A < 1e-12) {
        return out;
    }
    const double B = 2.0 * (fx * dx + fy * dy);
    const double C = fx * fx + fy * fy - radius * radius;
    const double disc = B * B - 4.0 * A * C;
    if (disc < 0.0) {
        return out;
    }
    const double sq = std::sqrt(disc);
    for (const double t : {(-B - sq) / (2.0 * A), (-B + sq) / (2.0 * A)}) {
        const Point p{a.x + t * dx, a.y + t * dy};
        out.push_back(std::atan2(p.y - center.y, p.x - center.x));
    }
    return out;
}

inline std::vector<ArcSeg> clipArc(Point center, double radius, Point ep1,
                                   Point ep2, int side,
                                   const std::vector<Point> &clip)
{
    std::vector<ArcSeg> result;
    if (radius <= 0.0 || ep1 == ep2) {
        return result;
    }
    const int keep = side >= 0 ? 1 : -1;
    const double th1 = std::atan2(ep1.y - center.y, ep1.x - center.x);
    const double th2 = std::atan2(ep2.y - center.y, ep2.x - center.x);
    auto sample = [&](double th) {
        return Point{center.x + radius * std::cos(th),
                     center.y + radius * std::sin(th)};
    };
    auto onKeepSide = [&](double th) {
        const Point p = sample(th);
        const double cr =
            (ep2.x - ep1.x) * (p.y - ep1.y) - (ep2.y - ep1.y) * (p.x - ep1.x);
        return cr * keep > 1e-9;
    };

    // 确定原弧方向：th1→th2 沿 +Δ 还是 -Δ（取各自中点判定哪段在保留侧）
    double d1 = th2 - th1;
    while (d1 < 0.0) {
        d1 += 2.0 * M_PI;
    }
    while (d1 >= 2.0 * M_PI) {
        d1 -= 2.0 * M_PI;
    }
    double thStart, thEnd;
    if (onKeepSide(th1 + d1 * 0.5)) {
        thStart = th1;
        thEnd = th1 + d1; // 递增方向
    } else {
        thStart = th1;
        thEnd = th1 - (2.0 * M_PI - d1); // 递减方向
    }
    // 统一成递增区间 [thStart, thEnd]（cos/sin 周期，交换端点不影响采样点）
    if (thEnd < thStart) {
        std::swap(thStart, thEnd);
    }

    // 收集分割角：原弧两个端点 + 窗口每条边与圆的交点（平移到 [thStart, thEnd]）
    std::vector<double> cuts{thStart, thEnd};
    for (std::size_t i = 0; i < clip.size(); ++i) {
        const Point a = clip[i];
        const Point b = clip[(i + 1) % clip.size()];
        for (double ang : circleEdgeAngles(center, radius, a, b)) {
            double angIn = ang;
            while (angIn < thStart - 1e-9) {
                angIn += 2.0 * M_PI;
            }
            while (angIn > thEnd + 2.0 * M_PI + 1e-9) {
                angIn -= 2.0 * M_PI;
            }
            // 在 (thStart, thEnd] 或 (thStart-2π, thEnd-2π] 两个候选副本中取落在区间内的
            for (double cand : {angIn, angIn - 2.0 * M_PI}) {
                if (cand >= thStart - 1e-9 && cand <= thEnd + 1e-9) {
                    cuts.push_back(cand);
                }
            }
        }
    }
    std::sort(cuts.begin(), cuts.end());
    cuts.erase(std::unique(cuts.begin(), cuts.end(),
                           [](double a, double b) { return std::abs(a - b) < 1e-6; }),
               cuts.end());

    // 凸多边形内部判定
    auto inWindow = [&](Point p) {
        for (std::size_t i = 0; i < clip.size(); ++i) {
            if (cross(clip[i], clip[(i + 1) % clip.size()], p) > 1e-9) {
                return false;
            }
        }
        return true;
    };

    for (std::size_t i = 0; i + 1 < cuts.size(); ++i) {
        const double a = cuts[i];
        const double b = cuts[i + 1];
        if (b - a < 1e-6) {
            continue;
        }
        if (inWindow(sample((a + b) * 0.5))) {
            // 新割线 ep1=sample(a) → ep2=sample(b) 与原割线不同，原 side 不再适用；
            // 取弧段中点独立算 side：让 drawArc 保留这段短弧本身
            const Point aPt = sample(a);
            const Point bPt = sample(b);
            const Point midPt = sample((a + b) * 0.5);
            const double cr = (bPt.x - aPt.x) * (midPt.y - aPt.y) -
                              (bPt.y - aPt.y) * (midPt.x - aPt.x);
            const int sideNew = cr >= 0.0 ? 1 : -1;
            result.push_back({aPt, bPt, sideNew});
        }
    }
    return result;
}

} // namespace Geometry

#endif // GEOMETRY_H
