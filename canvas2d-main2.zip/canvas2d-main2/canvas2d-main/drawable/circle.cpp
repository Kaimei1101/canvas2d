#include "circle.h"

#include "rendertarget.h"

Circle::Circle(Point center, double radius, bool fill, RGBA fillColor,
               bool stroke, double width, RGBA strokeColor, LineType lineType)
    : center{center}, radius{radius},
      arcData{Point{0, 0}, Point{0, 0}, 1, true}, // 整圆：无端点
      width{width}, strokeColor{strokeColor},
      fillColor{fillColor}, stroke{stroke}, fill{fill}, lineType{lineType}
{
}

Circle::Circle(Point center, Point edge, bool fill, RGBA fillColor, bool stroke,
               double width, RGBA strokeColor, LineType lineType)
    : Circle{center, center.distance(edge), fill,    fillColor, stroke,
             width,  strokeColor,           lineType}
{
}

Circle::Circle(Point center, double radius, Point ep1, Point ep2, int side,
               bool fill, RGBA fillColor, bool stroke, double width,
               RGBA strokeColor, LineType lineType)
    : center{center}, radius{radius},
      arcData{ep1, ep2, side >= 0 ? 1 : -1, false},
      width{width}, strokeColor{strokeColor},
      fillColor{fillColor}, stroke{stroke}, fill{fill}, lineType{lineType}
{
}

void Circle::draw(RenderTarget &rt) const
{
    if (fill && arcData.isFullCircle) {
        rt.fillCircle(center, radius, fillColor);
    }
    if (stroke) {
        if (arcData.isFullCircle) {
            rt.drawCircleOutline(center, radius, width, strokeColor, lineType);
        } else {
            rt.drawArc(center, radius, arcData.ep1, arcData.ep2, arcData.side,
                       width, strokeColor, lineType);
        }
    }
}
