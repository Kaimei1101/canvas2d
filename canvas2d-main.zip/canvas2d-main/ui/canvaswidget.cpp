#include "canvaswidget.h"

#include <algorithm>
#include <cmath>
#include <memory>

#include "drawable/circle.h"
#include "drawable/line.h"
#include "drawable/polygon.h"
#include "geometry.h"

CanvasWidget::CanvasWidget()
    : canvas{0, 0}, tool{Tool::Select}, lastPos{0, 0}, lineWidth{1},
      stroke{true}, fill{false}, strokeColor{0, 0, 0}, fillColor{0, 0, 0},
      arcPhase{ArcPhase::Idle}, arcCenter{0, 0}, arcRadius{0}, arcSecA{0, 0},
      arcSecB{0, 0}, arcEp1{0, 0}, arcEp2{0, 0}
{
    canvas.setScale(devicePixelRatio());
    setMouseTracking(true);
    setFocusPolicy(Qt::StrongFocus);
}

// 割线 P = a + t·d 代入圆方程，解一元二次方程（t 取全直线，不限线段）
// 有交点时写入 ep1、ep2 并返回 true
static bool intersectCircle(Point a, Point b, Point center, double radius,
                            Point &ep1, Point &ep2)
{
    const double dx = b.x - a.x;
    const double dy = b.y - a.y;
    const double fx = a.x - center.x;
    const double fy = a.y - center.y;

    const double qa = dx * dx + dy * dy;
    if (qa < 1e-12) {
        return false;
    }
    const double qb = 2.0 * (fx * dx + fy * dy);
    const double qc = fx * fx + fy * fy - radius * radius;
    const double disc = qb * qb - 4.0 * qa * qc;
    if (disc < 0) {
        return false;
    }
    const double sq = std::sqrt(disc);
    const double t1 = (-qb - sq) / (2.0 * qa);
    const double t2 = (-qb + sq) / (2.0 * qa);
    ep1 = Point{a.x + t1 * dx, a.y + t1 * dy};
    ep2 = Point{a.x + t2 * dx, a.y + t2 * dy};
    return true;
}

// 辅助标记：以 p 为中心的红色小十字（参照 ArcTool 的交点标记）
static void drawCross(Canvas &canvas, Point p)
{
    const RGBA red{220, 0, 0};
    canvas.drawShape(Line{Point{p.x - 3, p.y}, Point{p.x + 3, p.y}, 1, red,
                          LineType{}});
    canvas.drawShape(Line{Point{p.x, p.y - 3}, Point{p.x, p.y + 3}, 1, red,
                          LineType{}});
}

// 重心标记：方块（选中为红色，未选中为蓝色），边长以屏幕像素固定
static void drawCentroidMark(Canvas &canvas, Point p, bool selectedShape,
                             double scale)
{
    // 以屏幕像素固定的标记尺寸：转换回世界坐标
    const double half = 4.0 / scale;
    const RGBA color = selectedShape ? RGBA{220, 0, 0} : RGBA{0, 100, 220};
    std::vector<Point> verts = {
        Point{p.x - half, p.y - half},
        Point{p.x + half, p.y - half},
        Point{p.x + half, p.y + half},
        Point{p.x - half, p.y + half},
    };
    canvas.drawShape(Polygon{verts, true, color, true, 1, color, LineType{}});
}

// 组重心标记：较大的红色十字 + 圆圈感（用加粗十字表示）
static void drawGroupCentroidMark(Canvas &canvas, Point p, double scale)
{
    const double r = 7.0 / scale;
    const RGBA color{220, 0, 0};
    canvas.drawShape(Line{Point{p.x - r, p.y}, Point{p.x + r, p.y}, 2, color,
                          LineType{}});
    canvas.drawShape(Line{Point{p.x, p.y - r}, Point{p.x, p.y + r}, 2, color,
                          LineType{}});
}

void CanvasWidget::paintEvent(QPaintEvent *e)
{
    canvas.redraw();
    Point mouseWorld = canvas.getCamera().screenToWorld(lastPos);

    // 选择工具：所有重心亮起；选中多个时显示组重心
    if (tool == Tool::Select) {
        const auto &shapes = canvas.getShapes();
        const double scale = canvas.getScale();
        for (size_t i = 0; i < shapes.size(); ++i) {
            const bool isSel =
                std::find(selected.begin(), selected.end(), i) !=
                selected.end();
            drawCentroidMark(canvas, shapes[i]->centroid(), isSel, scale);
        }
        // 组重心：选中图形重心的算术平均
        if (selected.size() >= 2) {
            Point sum{0, 0};
            for (size_t idx : selected) {
                sum = sum + shapes[idx]->centroid();
            }
            drawGroupCentroidMark(
                canvas, sum / static_cast<double>(selected.size()), scale);
        }
    }

    switch (tool) {
    case Tool::Line:
        if (!operations.empty()) {
            canvas.drawShape(Line{operations.back(), mouseWorld,
                                  lineWidth, strokeColor, lineType});
        }
        break;

    case Tool::Circle:
        // 圆弧工具预览（参照 ArcTool::rebuildPreview）：
        // 圆：用当前画笔，所见即所得；割线：灰色虚线；弧端点：红色十字
        if (arcPhase != ArcPhase::Idle && arcRadius > 0) {
            canvas.drawShape(Circle{arcCenter, arcRadius, fill, fillColor,
                                    stroke, lineWidth, strokeColor, lineType});
        }
        if (arcPhase == ArcPhase::SecantDown ||
            arcPhase == ArcPhase::PickSide) {
            canvas.drawShape(Line{arcSecA, arcSecB, 1, RGBA{150, 150, 150},
                                  LineType{{4, 4, 4, 4}}});
        }
        if (arcPhase == ArcPhase::PickSide) {
            drawCross(canvas, arcEp1);
            drawCross(canvas, arcEp2);
        }
        break;

    case Tool::Polygon: {
        if (operations.empty()) {
            break;
        }
        auto verts = operations;
        verts.push_back(mouseWorld);
        canvas.drawShape(Polygon{std::move(verts), fill, fillColor, stroke,
                                 lineWidth, strokeColor, lineType});
        break;
    }

    case Tool::Clip: {
        // 裁剪窗口预览：已确认顶点构成的凸多边形轮廓 + 鼠标悬停反馈
        if (clipPts.empty()) {
            break;
        }
        const RGBA guide{90, 90, 90};
        const RGBA okColor{0, 130, 0};
        const LineType dash{{5, 4, 5, 4}};
        const std::size_t n = clipPts.size();

        // 已确认边
        for (std::size_t i = 0; i + 1 < n; ++i) {
            canvas.drawShape(
                Line{clipPts[i], clipPts[i + 1], 1, guide, LineType{}});
        }
        if (n >= 3) {
            // 闭合边
            canvas.drawShape(
                Line{clipPts.back(), clipPts.front(), 1, guide, LineType{}});
        }

        // 悬停的新点
        if (n == 1) {
            canvas.drawShape(
                Line{clipPts[0], mouseWorld, 1, guide, dash});
        } else if (n == 2) {
            std::vector<Point> tri;
            if (Geometry::makeTriangle(clipPts[0], clipPts[1], mouseWorld,
                                       tri)) {
                // 三角形合法：绿色虚线预览闭合轮廓
                canvas.drawShape(
                    Line{clipPts[0], mouseWorld, 1, okColor, dash});
                canvas.drawShape(
                    Line{clipPts[1], mouseWorld, 1, okColor, dash});
            } else {
                canvas.drawShape(
                    Line{clipPts[1], mouseWorld, 1, guide, dash});
            }
        } else {
            // n>=3：判定鼠标点对哪条边异侧
            const int edge = Geometry::convexInsertEdge(clipPts, mouseWorld);
            // 橡皮线：连到最近的待插入位置
            if (edge >= 0) {
                const Point &a = clipPts[edge];
                const Point &b = clipPts[(edge + 1) % n];
                // 未落下时以“这条边 + 新增端点”绘制三角形（绿色高亮）
                canvas.drawShape(Line{a, mouseWorld, 2, okColor, dash});
                canvas.drawShape(Line{b, mouseWorld, 2, okColor, dash});
                canvas.drawShape(Line{a, b, 2, okColor, LineType{}});
            } else {
                // 不合法：只显示到重心的灰色提示线
                const Point c = Geometry::centroid(clipPts);
                canvas.drawShape(Line{c, mouseWorld, 1, guide, dash});
            }
        }
        break;
    }
    }

    QImage img{canvas.getRenderTarget().getPixels().as_raw(), canvas.getWidth(),
               canvas.getHeight(), QImage::Format_RGBA8888};
    img.setDevicePixelRatio(devicePixelRatio());
    QPainter{this}.drawImage(0, 0, img);
}

void CanvasWidget::resizeEvent(QResizeEvent *e)
{
    canvas.resize(e->size().width() * devicePixelRatio(),
                  e->size().height() * devicePixelRatio());
}

void CanvasWidget::mouseMoveEvent(QMouseEvent *e)
{
    auto position = toPoint(e->position());
    if (e->buttons() & Qt::MiddleButton) {
        canvas.move_camera(lastPos - position);
        update();
    }

    if (tool == Tool::Circle) {
        auto worldPos = canvas.getCamera().screenToWorld(position);
        switch (arcPhase) {
        case ArcPhase::CenterDown:
            // 拖动中：更新半径预览
            arcRadius = arcCenter.distance(worldPos);
            update();
            break;
        case ArcPhase::SecantDown:
            // 拖动中：更新割线端点
            arcSecB = worldPos;
            update();
            break;
        case ArcPhase::RadiusDone:
        case ArcPhase::PickSide:
            // 静态预览，无需更新
            break;
        default:
            break;
        }
    } else if (tool == Tool::Clip) {
        update();
    } else if (!operations.empty()) {
        update();
    }

    lastPos = position;
    emit mouseWorldPos(canvas.getCamera().screenToWorld(position));
    e->accept();
}

void CanvasWidget::mousePressEvent(QMouseEvent *e)
{
    auto worldPos = canvas.getCamera().screenToWorld(toPoint(e->position()));

    // 圆弧工具：右键随时取消
    if (tool == Tool::Circle && e->button() == Qt::RightButton) {
        if (arcPhase != ArcPhase::Idle) {
            arcPhase = ArcPhase::Idle;
            update();
        }
        e->accept();
        return;
    }

    // 多边形工具：右键完成（≥3 点提交为正式多边形，不足 3 点取消）
    if (tool == Tool::Polygon && e->button() == Qt::RightButton) {
        if (operations.size() >= 3) {
            canvas.addShape(std::make_unique<Polygon>(
                operations, fill, fillColor, stroke, lineWidth, strokeColor,
                lineType));
        }
        operations.clear();
        update();
        e->accept();
        return;
    }

    // 裁剪工具：右键完成窗口并执行裁剪（不足 3 点取消）
    if (tool == Tool::Clip && e->button() == Qt::RightButton) {
        if (clipPts.size() >= 3) {
            applyClip();
        }
        clipPts.clear();
        update();
        e->accept();
        return;
    }

    if (tool == Tool::Circle && e->button() == Qt::LeftButton) {
        switch (arcPhase) {
        case ArcPhase::Idle:
            // 第一次按下：确定圆心
            arcCenter = worldPos;
            arcRadius = 0;
            arcPhase = ArcPhase::CenterDown;
            update();
            break;

        case ArcPhase::RadiusDone:
            // 第二次按下：开始画割线
            arcSecA = worldPos;
            arcSecB = worldPos;
            arcPhase = ArcPhase::SecantDown;
            update();
            break;

        case ArcPhase::PickSide: {
            // 第三次点击：确定保留侧（相对 ep1→ep2 方向表达）
            const double dx = arcEp2.x - arcEp1.x;
            const double dy = arcEp2.y - arcEp1.y;
            const double cross = dx * (worldPos.y - arcEp1.y) -
                                 dy * (worldPos.x - arcEp1.x);
            if (std::abs(cross) < 1e-6) {
                // 点击恰在割线上，无效，保持选侧状态
                break;
            }
            canvas.addShape(std::make_unique<Circle>(
                arcCenter, arcRadius, arcEp1, arcEp2, cross > 0 ? 1 : -1,
                fill, fillColor, stroke, lineWidth, strokeColor, lineType));
            arcPhase = ArcPhase::Idle;
            update();
            break;
        }

        default:
            break;
        }
        e->accept();
        return;
    }

    if (e->button() == Qt::LeftButton) {
        switch (tool) {
        case Tool::Select: {
            // 重心拾取：点击重心切换对应图形的选中状态；
            // 未命中任何重心时清空选择
            const auto &shapes = canvas.getShapes();
            const double pickWorld = PICK_RADIUS / canvas.getScale();
            size_t hitIdx = shapes.size();
            double bestDist = pickWorld;
            for (size_t i = 0; i < shapes.size(); ++i) {
                const double d = shapes[i]->centroid().distance(worldPos);
                if (d <= bestDist) {
                    bestDist = d;
                    hitIdx = i;
                }
            }
            if (hitIdx < shapes.size()) {
                auto it = std::find(selected.begin(), selected.end(), hitIdx);
                if (it != selected.end()) {
                    selected.erase(it); // 再次点击取消选中
                } else {
                    selected.push_back(hitIdx);
                }
            } else {
                selected.clear();
            }
            update();
            break;
        }
        case Tool::Line:
            if (!operations.empty()) {
                canvas.addShape(std::make_unique<Line>(operations.back(),
                                                       worldPos, lineWidth,
                                                       strokeColor, lineType));
                operations.pop_back();
                update();
            }
            operations.push_back(worldPos);
            break;
        case Tool::Polygon:
            operations.push_back(worldPos);
            break;
        case Tool::Fill: {
            // 实验二-2：点击判定是否落在合法封闭图形内，
            // 若合法则把图形填充属性改为当前填充色；
            // 多个图形重叠时填充最上层（数组末尾）的一个
            const auto &shapes = canvas.getShapes();
            for (auto it = shapes.rbegin(); it != shapes.rend(); ++it) {
                if ((*it)->isClosed() && (*it)->contains(worldPos)) {
                    (*it)->setFill(fillColor);
                    canvas.markDirty();
                    update();
                    break;
                }
            }
            break;
        }
        case Tool::Clip: {
            // 实验二-4：凸多边形裁剪窗口的自动排序增量构造
            const std::size_t n = clipPts.size();
            if (n == 0) {
                clipPts.push_back(worldPos);
            } else if (n == 1) {
                if (clipPts[0].distance(worldPos) >= 1e-6) {
                    clipPts.push_back(worldPos);
                }
            } else if (n == 2) {
                // 第三个点：非共线才形成三角形，自动确定绕序
                std::vector<Point> tri;
                if (Geometry::makeTriangle(clipPts[0], clipPts[1], worldPos,
                                           tri)) {
                    clipPts = std::move(tri);
                }
                // 共线：视为没有点击
            } else {
                // n>=3：有且仅有一条边与重心异侧才合法，
                // 新点插入该边两端点之间；否则视为没有点击
                const int edge = Geometry::convexInsertEdge(clipPts, worldPos);
                if (edge >= 0) {
                    clipPts.insert(
                        clipPts.begin() + edge + 1, worldPos);
                }
            }
            update();
            break;
        }
        }
    }

    e->accept();
}

// 实验二-4：裁剪窗口完成后执行裁剪。
// 以窗口重心命中一个合法封闭图形（与填充工具一致，取最上层）：
//   多边形直接作为被裁剪多边形；整圆先采样为多边形；
//   Sutherland-Hodgman 求交，结果 <3 点表示图形被完全裁掉（删除），
//   否则用交集多边形替换原图形并继承其填充/描边属性。
// 裁剪结果是普通 Polygon，再次被裁剪时自然走同一流程（视作重新绘制窗口）。
void CanvasWidget::applyClip()
{
    if (clipPts.size() < 3) {
        return;
    }
    const Point winCenter = Geometry::centroid(clipPts);
    const auto &shapes = canvas.getShapes();

    std::size_t hit = shapes.size();
    for (std::size_t i = shapes.size(); i-- > 0;) {
        if (shapes[i]->isClosed() && shapes[i]->contains(winCenter)) {
            hit = i;
            break;
        }
    }
    if (hit == shapes.size()) {
        return; // 窗口重心不在任何封闭图形内：不处理
    }

    const Drawable *orig = shapes[hit].get();
    std::vector<Point> subject;
    bool doFill = false;
    RGBA fColor{0, 0, 0};
    bool doStroke = true;
    RGBA sColor{0, 0, 0};
    double w = lineWidth;
    LineType lt;

    if (const auto *poly = dynamic_cast<const Polygon *>(orig)) {
        subject = poly->getVerts();
        doFill = poly->isFilled();
        fColor = poly->getFillColor();
        doStroke = poly->isStroked();
        sColor = poly->getStrokeColor();
        w = poly->getLineWidth();
        lt = poly->getLineType();
    } else if (const auto *circ = dynamic_cast<const Circle *>(orig)) {
        subject = Geometry::circleToPolygon(circ->getCenter(),
                                            circ->getRadius());
        doFill = circ->isFilled();
        fColor = circ->getFillColor();
        doStroke = circ->isStroked();
        sColor = circ->getStrokeColor();
        w = circ->getLineWidth();
        lt = circ->getLineType();
    } else {
        return;
    }

    std::vector<Point> result = Geometry::clipPolygon(subject, clipPts);
    if (result.size() < 3) {
        canvas.removeShape(hit); // 窗口外无残留：图形被完全裁掉
    } else {
        auto clipped = std::make_unique<Polygon>(std::move(result), doFill,
                                                 fColor, doStroke, w, sColor,
                                                 lt);
        canvas.removeShape(hit);
        canvas.addShape(std::move(clipped));
    }
    selected.clear();
}

void CanvasWidget::mouseReleaseEvent(QMouseEvent *e)
{
    auto worldPos = canvas.getCamera().screenToWorld(toPoint(e->position()));

    if (tool == Tool::Circle && e->button() == Qt::LeftButton) {
        switch (arcPhase) {
        case ArcPhase::CenterDown:
            // 松开确定半径；半径过小视为无效
            arcRadius = arcCenter.distance(worldPos);
            if (arcRadius < 1) {
                arcPhase = ArcPhase::Idle;
            } else {
                arcPhase = ArcPhase::RadiusDone;
            }
            update();
            break;

        case ArcPhase::SecantDown: {
            arcSecB = worldPos;
            if (arcSecB == arcSecA) {
                // 未形成有效割线，回到画割线前的状态重新操作
                arcPhase = ArcPhase::RadiusDone;
                update();
                break;
            }
            const bool hit =
                intersectCircle(arcSecA, arcSecB, arcCenter, arcRadius,
                                arcEp1, arcEp2);
            if (!hit || arcEp1.distance(arcEp2) < 2.0) {
                // 无交点（含相切退化）：创建整圆
                canvas.addShape(std::make_unique<Circle>(
                    arcCenter, arcRadius, fill, fillColor, stroke, lineWidth,
                    strokeColor, lineType));
                arcPhase = ArcPhase::Idle;
            } else {
                arcPhase = ArcPhase::PickSide;
            }
            update();
            break;
        }

        default:
            break;
        }
        e->accept();
        return;
    }

    e->accept();
}

void CanvasWidget::wheelEvent(QWheelEvent *e)
{
    double delta;
    if (!e->pixelDelta().isNull()) {
        delta = e->pixelDelta().y() / 50.0;
    } else {
        delta = e->angleDelta().y() / 120.0;
    }
    if (delta == 0.0) {
        return;
    }

    double base = e->modifiers() & Qt::ControlModifier ? 1.02 : 1.1;
    double factor = std::pow(base, delta);
    auto position = toPoint(e->position());
    canvas.zoomAt(position, factor);
    update();
    emit mouseWorldPos(canvas.getCamera().screenToWorld(position));
    emit scaleChanged(canvas.getScale() / devicePixelRatio());
    e->accept();
}

void CanvasWidget::keyPressEvent(QKeyEvent *e)
{
    if (e->key() == Qt::Key_Escape) {
        if (!operations.empty()) {
            operations.clear();
            update();
        }
        if (arcPhase != ArcPhase::Idle) {
            arcPhase = ArcPhase::Idle;
            update();
        }
        if (!selected.empty()) {
            selected.clear();
            update();
        }
        if (!clipPts.empty()) {
            clipPts.clear();
            update();
        }
    }
}

Point CanvasWidget::toPoint(QPointF pos) const
{
    return Point{
        pos.x() * devicePixelRatio(),
        pos.y() * devicePixelRatio(),
    };
}
