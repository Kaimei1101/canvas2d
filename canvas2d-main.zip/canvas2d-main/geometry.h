#ifndef GEOMETRY_H
#define GEOMETRY_H

// 纯几何算法模块（实验二裁剪），不依赖 Qt/RenderTarget，保持低耦合
#include <cmath>
#include <vector>

#include "point.h"

namespace Geometry {

// 叉积 (b-a) × (c-a)
inline double cross(Point a, Point b, Point c)
{
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

// 有符号面积的两倍；y 向下坐标系中 <0 对应屏幕逆时针绕序
inline double signedArea2(const std::vector<Point> &p)
{
    double s = 0;
    for (std::size_t i = 0; i < p.size(); ++i) {
        const Point &a = p[i];
        const Point &b = p[(i + 1) % p.size()];
        s += a.x * b.y - b.x * a.y;
    }
    return s;
}

inline Point centroid(const std::vector<Point> &p)
{
    Point s{0, 0};
    for (const auto &q : p) {
        s = s + q;
    }
    return p.empty() ? s : s / static_cast<double>(p.size());
}

// 凸多边形窗口增量构造（实验二-4 窗口确定）：
// pts 为固定绕序（signedArea2 <= 0，屏幕逆时针）的凸 n 边形环序顶点，
// 判定新点 p 是否“有且仅有对一条边与重心异侧”。
// 合法时返回该边的起点下标 i（新点应插入 pts[i] 与 pts[(i+1)%n] 之间），
// 否则返回 -1（点在内部/边界上，或对多条边异侧）。
inline int convexInsertEdge(const std::vector<Point> &pts, Point p)
{
    const std::size_t n = pts.size();
    if (n < 3) {
        return -1;
    }
    const Point c = centroid(pts);
    int outside = -1;
    for (std::size_t i = 0; i < n; ++i) {
        const Point &a = pts[i];
        const Point &b = pts[(i + 1) % n];
        const double sc = cross(a, b, c);
        const double sp = cross(a, b, p);
        if (sc * sp < 0) { // 严格异侧
            if (outside != -1) {
                return -1; // 多于一条边异侧：不合法
            }
            outside = static_cast<int>(i);
        }
    }
    return outside; // -1 表示点在内部/边上，同样不合法
}

// 由两个已确认点 + 新点生成固定绕序的三角形；共线返回 false
inline bool makeTriangle(Point a, Point b, Point p, std::vector<Point> &out)
{
    if (std::abs(cross(a, b, p)) < 1e-9) {
        return false;
    }
    out = {a, b, p};
    if (signedArea2(out) > 0) {
        std::swap(out[1], out[2]); // 统一为屏幕逆时针绕序
    }
    return true;
}

// 线段 S->E 与直线 A->B 的交点参数 t（P = S + t·(E-S)）
inline double edgeIntersectParam(Point s, Point e, Point a, Point b)
{
    const double ux = e.x - s.x;
    const double uy = e.y - s.y;
    const double vx = b.x - a.x;
    const double vy = b.y - a.y;
    const double denom = ux * vy - uy * vx;
    return ((a.x - s.x) * vy - (a.y - s.y) * vx) / denom;
}

// Sutherland-Hodgman：用凸裁剪窗口（屏幕逆时针绕序）裁剪多边形 subject
inline std::vector<Point> clipPolygon(const std::vector<Point> &subject,
                                      const std::vector<Point> &clip)
{
    std::vector<Point> out = subject;
    const std::size_t m = clip.size();
    for (std::size_t i = 0; i < m && !out.empty(); ++i) {
        const Point a = clip[i];
        const Point b = clip[(i + 1) % m];
        std::vector<Point> in = std::move(out);
        out.clear();
        // 屏幕逆时针绕序：内部满足 cross(a,b,p) <= 0
        auto inside = [&](Point p) { return cross(a, b, p) <= 1e-9; };
        Point s = in.back();
        bool sin = inside(s);
        for (const Point &e : in) {
            const bool ein = inside(e);
            if (sin) {
                if (ein) {
                    out.push_back(e); // 内->内
                } else {
                    const double t = edgeIntersectParam(s, e, a, b);
                    out.push_back(
                        Point{s.x + t * (e.x - s.x), s.y + t * (e.y - s.y)});
                }
            } else if (ein) {
                const double t = edgeIntersectParam(s, e, a, b);
                out.push_back(
                    Point{s.x + t * (e.x - s.x), s.y + t * (e.y - s.y)});
                out.push_back(e); // 外->内
            }
            s = e;
            sin = ein;
        }
    }
    return out;
}

// 整圆按 seg 段采样为多边形（裁剪时圆不再是圆，结果用多边形表示）
inline std::vector<Point> circleToPolygon(Point center, double radius,
                                          int seg = 64)
{
    std::vector<Point> pts;
    pts.reserve(seg);
    for (int i = 0; i < seg; ++i) {
        const double t = 2.0 * M_PI * i / seg;
        pts.push_back(
            Point{center.x + radius * std::cos(t), center.y + radius * std::sin(t)});
    }
    return pts;
}

} // namespace Geometry

#endif // GEOMETRY_H
